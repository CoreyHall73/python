from flask import Flask, render_template, request, redirect
from user import User

app = Flask(__name__)
@app.route("/")
def index():
    users = User.get_all()
    print(users)
    return render_template("read(all).html", users=users)

@app.route('/add')
def add():
    return render_template("create.html")

@app.route('/create', methods=['POST'])
def create():
    print(request.form)
    User.save(request.form)
    return redirect('/')

@app.route('/user/edit/<int:id>')
def edit(id):
    data ={ 
        "id":id
    }
    return render_template("edit.html",user=User.get_one(data))

@app.route('/update_user',methods=['POST'])
def update():
    print(request.form)
    User.update(request.form)
    return redirect('/')

@app.route('/show/<int:id>')
def show(id):
    data ={ 
        "id":id
    }
    return render_template("read(one).html",user=User.get_one(data))

@app.route('/destroy/<int:id>')
def destroy(id):
    data ={
        'id': id
    }
    User.destroy(data)
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)